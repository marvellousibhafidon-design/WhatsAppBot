const fs = require('fs');
const path = require('path');

module.exports = async (sock, sender, args) => {
    if (!args[0]) return await sock.sendMessage(sender, { text: 'Usage: .view filename' });

    const filePath = path.join(__dirname, '..', 'media', args[0]);
    if (fs.existsSync(filePath)) {
        await sock.sendMessage(sender, { document: fs.readFileSync(filePath), fileName: args[0] });
    } else {
        await sock.sendMessage(sender, { text: 'File not found.' });
    }
};