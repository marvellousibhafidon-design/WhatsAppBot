module.exports = async (sock, sender, args) => {
    if (!args[0]) return await sock.sendMessage(sender, { text: 'Usage: .download filename' });
    await sock.sendMessage(sender, { text: `Preparing download: ${args[0]}` });
    // Add actual download logic if needed
};