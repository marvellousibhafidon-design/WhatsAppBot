module.exports = async (sock, sender) => {
    await sock.sendMessage(sender, { text: 'Send media to save. (Future logic for automatic saving)' });
};