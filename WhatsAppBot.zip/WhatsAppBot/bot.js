const { default: makeWASocket, useSingleFileAuthState, fetchLatestBaileysVersion, DisconnectReason } = require("@adiwajshing/baileys");
const { state, saveState } = useSingleFileAuthState('./sessions/session.json');
const qrcode = require('qrcode-terminal');
const fs = require('fs');
const path = require('path');

async function startBot() {
    const { version } = await fetchLatestBaileysVersion();
    const sock = makeWASocket({
        version,
        auth: state,
        printQRInTerminal: true,
    });

    sock.ev.on('creds.update', saveState);

    sock.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect, qr } = update;
        if (qr) qrcode.generate(qr, { small: true });
        if (connection === 'close') {
            if ((lastDisconnect.error)?.output?.statusCode !== DisconnectReason.loggedOut) {
                startBot();
            }
        }
    });

    // Listen for messages
    sock.ev.on('messages.upsert', async (m) => {
        const msg = m.messages[0];
        if (!msg.message || msg.key.fromMe) return;

        const text = msg.message.conversation || msg.message.extendedTextMessage?.text;
        const sender = msg.key.remoteJid;

        if (!text) return;

        // Command: .view
        if (text.startsWith('.view')) {
            const parts = text.split(' ');
            if (parts[1]) {
                const filePath = path.join(__dirname, 'media', parts[1]);
                if (fs.existsSync(filePath)) {
                    await sock.sendMessage(sender, { document: fs.readFileSync(filePath), fileName: parts[1] });
                } else {
                    await sock.sendMessage(sender, { text: 'File not found.' });
                }
            } else {
                await sock.sendMessage(sender, { text: 'Usage: .view filename' });
            }
        }

        // Command: .save
        if (text.startsWith('.save')) {
            await sock.sendMessage(sender, { text: 'Send media to save.' });
        }

        // Command: .download
        if (text.startsWith('.download')) {
            const parts = text.split(' ');
            if (parts[1]) {
                await sock.sendMessage(sender, { text: `Preparing download: ${parts[1]}` });
                // actual download logic can be added
            }
        }
    });
}

startBot();